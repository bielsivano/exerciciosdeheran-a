public class figuraGeometrica {

    public Double base;
    public Double altura;

    public figuraGeometrica(Double base, Double altura){
        this.base = base;
        this.altura = altura;

    }
}
