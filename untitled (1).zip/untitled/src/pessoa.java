public class pessoa {
   public String nome;

   public String telefone;

   public String endereco;

   public  pessoa(String _nome, String telefone, String endereco){
       this.nome = _nome;
       this.telefone = telefone;
       this.endereco = telefone;

   }

}
